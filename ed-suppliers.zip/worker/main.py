import time

if __name__ == "__main__":
    while True:
        print("[worker] Waiting for future logic: EDDN listener, EDSM parser...")
        time.sleep(60)
